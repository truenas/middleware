/* krb5-types.h -- this file was generated for i386-unknown-freebsd5.0 by
                   $Id: bits.c,v 1.22 2002/08/28 16:08:44 joda Exp $ */

/* $FreeBSD: releng/9.3/kerberos5/include/krb5-types.h 102649 2002-08-30 21:33:20Z nectar $ */

#ifndef __krb5_types_h__
#define __krb5_types_h__

#include <inttypes.h>
#include <sys/types.h>
#include <sys/socket.h>

typedef socklen_t krb5_socklen_t;
#include <unistd.h>
typedef ssize_t krb5_ssize_t;

#endif /* __krb5_types_h__ */
