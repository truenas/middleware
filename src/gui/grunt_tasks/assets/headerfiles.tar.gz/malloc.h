/* $FreeBSD: releng/9.3/include/malloc.h 86178 2001-11-07 23:14:31Z obrien $ */
#if __STDC__
#error "<malloc.h> has been replaced by <stdlib.h>"
#else
#include <stdlib.h>
#endif
