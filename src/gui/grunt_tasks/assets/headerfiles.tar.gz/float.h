/*-
 * This file is in the public domain.
 */
/* $FreeBSD: releng/9.3/sys/amd64/include/float.h 263543 2014-03-21 20:21:23Z emaste $ */

#include <x86/float.h>
